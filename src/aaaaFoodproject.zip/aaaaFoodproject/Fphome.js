import React from 'react'
import '../App.css';
export default function Fphome() {
  return (
    
    <div className="App"style={{height:"270px",width:"1550px" }} >
      <form className='back'>

      </form>
        <center>
        home
        </center>
        </div>

    
  )
}
